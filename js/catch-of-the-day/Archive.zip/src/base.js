// React/Firebase package to mirror data changes
import Rebase from 're-base';
import firebase from 'firebase';

const firebaseApp = new firebase();
