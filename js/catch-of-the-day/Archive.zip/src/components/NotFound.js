import React from 'react';

const NotFound = () => <div>Not found.</div>;

export default NotFound;
